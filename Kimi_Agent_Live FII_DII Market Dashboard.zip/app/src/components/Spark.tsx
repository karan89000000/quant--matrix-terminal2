// Tiny SVG sparkline; stroke follows trend direction.
export default function Spark({ points, w = 150, h = 44 }: { points: number[]; w?: number; h?: number }) {
  if (!points || points.length < 2) return null;
  const min = Math.min(...points), max = Math.max(...points);
  const span = max - min || 1;
  const step = w / (points.length - 1);
  const xy = points.map((p, i) => `${(i * step).toFixed(1)},${(h - 4 - ((p - min) / span) * (h - 8)).toFixed(1)}`);
  const rising = points[points.length - 1] >= points[0];
  const color = rising ? "var(--pos)" : "var(--neg)";
  return (
    <svg className="spark" width={w} height={h} viewBox={`0 0 ${w} ${h}`} aria-hidden>
      <polygon points={`0,${h} ${xy.join(" ")} ${w},${h}`} fill={color} opacity=".09" />
      <polyline points={xy.join(" ")} fill="none" stroke={color} strokeWidth="1.6" strokeLinejoin="round" />
      <circle cx={w} cy={xy[xy.length - 1].split(",")[1]} r="2.6" fill={color} />
    </svg>
  );
}
