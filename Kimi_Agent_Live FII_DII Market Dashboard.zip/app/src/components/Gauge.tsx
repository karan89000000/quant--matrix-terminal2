// Semicircle gauge for a -100..+100 sentiment score.
export default function Gauge({ score, size = 84 }: { score: number; size?: number }) {
  const w = size, h = size * 0.62, cx = w / 2, cy = h - 6, r = w / 2 - 7;
  const angle = Math.PI - ((score + 100) / 200) * Math.PI; // π (left, -100) → 0 (right, +100)
  const nx = cx + r * 0.78 * Math.cos(angle);
  const ny = cy - r * 0.78 * Math.sin(angle);
  const color = score >= 20 ? "var(--pos)" : score <= -20 ? "var(--neg)" : "var(--warn)";

  const arc = (from: number, to: number) => {
    const a1 = Math.PI - ((from + 100) / 200) * Math.PI;
    const a2 = Math.PI - ((to + 100) / 200) * Math.PI;
    const p = (a: number) => `${cx + r * Math.cos(a)},${cy - r * Math.sin(a)}`;
    return `M ${p(a1)} A ${r} ${r} 0 0 1 ${p(a2)}`;
  };

  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} aria-hidden>
      <path d={arc(-100, -20)} stroke="var(--neg)" strokeWidth="5" fill="none" opacity=".28" strokeLinecap="round" />
      <path d={arc(-20, 20)} stroke="var(--warn)" strokeWidth="5" fill="none" opacity=".28" strokeLinecap="round" />
      <path d={arc(20, 100)} stroke="var(--pos)" strokeWidth="5" fill="none" opacity=".28" strokeLinecap="round" />
      <line x1={cx} y1={cy} x2={nx} y2={ny} stroke={color} strokeWidth="2.4" strokeLinecap="round" />
      <circle cx={cx} cy={cy} r="4" fill={color} />
    </svg>
  );
}
