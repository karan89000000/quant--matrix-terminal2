import Chart from "./Chart";
import Kit from "../lib/kit.js";
import type { FlowRow } from "@contracts/market";

// Daily FII vs DII net flows (₹ Cr) with cumulative institutional line.
export default function FlowsChart({ flows }: { flows: FlowRow[] }) {
  const rows = [...flows].reverse(); // oldest → newest

  const build = () => {
    const dates = rows.map((r) => r.date.slice(5)); // MM-DD
    let cum = 0;
    const cumLine = rows.map((r) => +(cum += r.fiiCash + r.diiCash).toFixed(0));
    return {
      legend: {
        top: 0, right: 0, icon: "rect", itemWidth: 9, itemHeight: 9,
        textStyle: { color: "#8b96a5", fontSize: 10.5, fontFamily: "Geist Mono Variable, monospace" },
      },
      tooltip: { trigger: "axis", valueFormatter: (v: number) => `₹${Number(v).toLocaleString("en-IN")} Cr` },
      xAxis: Kit.axis("category", { data: dates }),
      yAxis: Kit.axis("value", { scale: true }),
      series: [
        {
          name: "FII net", type: "bar", barMaxWidth: 8,
          data: rows.map((r) => +r.fiiCash.toFixed(0)),
          itemStyle: { color: "#3b82f6", borderRadius: [2, 2, 0, 0] },
        },
        {
          name: "DII net", type: "bar", barMaxWidth: 8,
          data: rows.map((r) => +r.diiCash.toFixed(0)),
          itemStyle: { color: "#f0b90b", borderRadius: [2, 2, 0, 0] },
        },
        {
          name: "Institutional cumulative", type: "line", smooth: true, symbol: "none",
          data: cumLine, lineStyle: { width: 1.6, color: "#e8edf3", type: "dashed" },
        },
      ],
    };
  };

  return <Chart build={build} deps={[flows]} className="chart" />;
}
