/* ECharts 宿主。图表实例是命令式的，而且 Kit 有一份注册表用来在主题切换时就地重建
   —— 所以这里只把一个空 div 交给 Kit.chart，之后靠 Kit.update 推新配置，React 不去
   碰这个子树。卸载时要 release，否则主题一变，Kit 还会去重建一个已经不在页面上的图。 */
import { useEffect, useRef } from 'react'
import Kit from '../lib/kit.js'

export default function Chart({ id, build, deps = [], className = 'chart', style }: {
  id?: string
  build: () => object
  deps?: unknown[]
  className?: string
  style?: React.CSSProperties
}) {
  const host = useRef<HTMLDivElement>(null)
  const inst = useRef<{ resize: () => void } | null>(null)
  const latest = useRef(build)
  latest.current = build

  useEffect(() => {
    inst.current = Kit.chart(host.current, () => latest.current())
    return () => { Kit.release(inst.current); inst.current = null }
  }, [])

  /* 挂载那一次由 Kit.chart 自己画完了，这里跳过；而且推新配置得走合并，
     Kit.chart 是把 Kit.base() 和 build() 合在一起下的，整份替换会把 base
     里的 tooltip / grid 一起抹掉。 */
  const first = useRef(true)
  useEffect(() => {
    if (first.current) { first.current = false; return }
    if (inst.current) Kit.update(inst.current, latest.current())
  }, deps)

  return <div className={className} id={id} style={style} ref={host} />
}
