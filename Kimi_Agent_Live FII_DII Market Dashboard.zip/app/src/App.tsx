import { useEffect, useRef, useState } from "react";
import { trpc } from "./providers/trpc";
import Gauge from "./components/Gauge";
import Spark from "./components/Spark";
import FlowsChart from "./components/FlowsChart";
import { inr, cr, pct, cls } from "./lib/format";
import type { IndexSnap, MarketSnapshot, Sentiment } from "@contracts/market";

const POLL_MS = 45_000;

const istClock = () =>
  new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
  }).format(new Date());

const labelCls = (l: Sentiment["label"]) =>
  l === "BULLISH" ? "up" : l === "BEARISH" ? "dn" : "";

/* ── index tape card ────────────────────────────────────────────────── */
function TapeCard({ idx, flash }: { idx: IndexSnap; flash: "" | "flash-up" | "flash-dn" }) {
  return (
    <div className="tcard">
      <div className="who">
        <div className="nm">{idx.name}</div>
        <div className="sub">{idx.symbol === "NIFTY" ? "NSE · REAL-TIME" : "BSE · NEAR REAL-TIME"}</div>
      </div>
      <div>
        <div className={`pv num ${flash}`}>{inr(idx.price)}</div>
        <div className={`chg num ${cls(idx.dayChange)}`}>
          {idx.dayChange >= 0 ? "▲" : "▼"} {inr(Math.abs(idx.dayChange))} ({pct(idx.dayChangePct)})
        </div>
      </div>
      <Spark points={idx.spark} />
    </div>
  );
}

/* ── one sentiment row (gauge + readout) ────────────────────────────── */
function GaugeRow({ name, s, sub }: { name: string; s: Sentiment; sub?: string }) {
  return (
    <div className={`gauge ${name === "OVERALL" ? "overall" : ""}`}>
      <Gauge score={s.score} />
      <div className="g-info">
        <div className="g-name">{name}</div>
        <div className={`g-label num ${labelCls(s.label)}`}>{s.label}</div>
        <div className="g-score">
          score {s.score > 0 ? "+" : ""}{s.score.toFixed(0)} / ±100{sub ? ` · ${sub}` : ""}
        </div>
      </div>
    </div>
  );
}

/* ── main ───────────────────────────────────────────────────────────── */
export default function App() {
  const q = trpc.market.snapshot.useQuery(undefined, { refetchInterval: POLL_MS });
  const data: MarketSnapshot | undefined = q.data;

  const [clock, setClock] = useState(istClock);
  const [countdown, setCountdown] = useState(POLL_MS / 1000);
  useEffect(() => {
    const t = setInterval(() => {
      setClock(istClock());
      const left = Math.max(0, POLL_MS - (Date.now() - q.dataUpdatedAt));
      setCountdown(Math.ceil(left / 1000));
    }, 1000);
    return () => clearInterval(t);
  }, [q.dataUpdatedAt]);

  /* flash the tape price when it moves */
  const prevPrices = useRef<Record<string, number>>({});
  const flashes: Record<string, "" | "flash-up" | "flash-dn"> = {};
  if (data) {
    for (const i of data.indices) {
      const prev = prevPrices.current[i.symbol];
      flashes[i.symbol] = prev == null || prev === i.price ? "" : i.price > prev ? "flash-up" : "flash-dn";
      prevPrices.current[i.symbol] = i.price;
    }
  }

  const nifty = data?.indices.find((i) => i.symbol === "NIFTY");
  const sensex = data?.indices.find((i) => i.symbol === "SENSEX");
  const lf = data?.latestFlow ?? null;

  const flowFor = (days: number) => data?.windows.find((w) => w.days === days) ?? null;

  return (
    <>
      <header>
        <div className="logo">
          FII/DII <em>TERMINAL</em>
          <small>INSTITUTIONAL FLOW DESK · NSE / BSE</small>
        </div>
        <div className="hspace" />
        <span className={`status ${data?.marketOpen ? "on" : "off"}`}>
          <i className="dot" />
          {data ? (data.marketOpen ? "MARKET LIVE" : "MARKET CLOSED") : "CONNECTING"}
        </span>
        <span className="clock">IST <b>{clock}</b></span>
        <span className="refresh">
          <span>next pull {countdown}s</span>
          <button onClick={() => q.refetch()} disabled={q.isFetching} title="Refresh now">
            {q.isFetching ? "…" : "⟳"}
          </button>
        </span>
      </header>

      <div className="tape">
        {nifty && <TapeCard idx={nifty} flash={flashes.NIFTY ?? ""} />}
        {sensex && <TapeCard idx={sensex} flash={flashes.SENSEX ?? ""} />}
        {!data && <div className="skel" style={{ gridColumn: "1/-1" }}>CONNECTING TO LIVE FEEDS…</div>}
      </div>

      {q.isError && (
        <div className="err-banner">
          Live feeds unreachable — retrying automatically. Last error: {String(q.error?.message ?? "").slice(0, 140)}
        </div>
      )}

      {data && (
        <main>
          {/* ── verdict ── */}
          <section className="panel" id="verdict">
            <div className="p-head">
              <h2>Institutional Verdict</h2>
              <span className="tag">FLOW-WEIGHTED</span>
            </div>
            <div className="p-body gauges">
              <GaugeRow name="OVERALL" s={data.overall} sub={`momentum ${data.overall.momentumScore > 0 ? "+" : ""}${data.overall.momentumScore.toFixed(0)}`} />
              <GaugeRow
                name="FII · FOREIGN"
                s={data.fii}
                sub={data.fii.basis.d1 != null ? `today ${cr(data.fii.basis.d1)}` : undefined}
              />
              <GaugeRow
                name="DII · DOMESTIC"
                s={data.dii}
                sub={data.dii.basis.d1 != null ? `today ${cr(data.dii.basis.d1)}` : undefined}
              />
              <div className="g-note">
                <b>How the read is built:</b> 50% latest session net flow, 30% 10-session
                average, 20% 20-session average — normalised against typical daily flow.
                FII adds a 20% tint from index-futures positioning. Overall = 45% FII +
                30% DII + 25% index momentum (1/10/20/60-day drift). ≥ +20 bullish, ≤ −20 bearish.
              </div>
            </div>
          </section>

          {/* ── timeframe matrix ── */}
          <section className="panel" id="matrix">
            <div className="p-head">
              <h2>Flows × Index · Timeframe Matrix</h2>
              <span className="tag">TRADING SESSIONS</span>
            </div>
            <div className="p-body">
              <table className="mx">
                <thead>
                  <tr>
                    <th>WINDOW</th>
                    <th>NIFTY 50</th>
                    <th>SENSEX</th>
                    <th>FII NET</th>
                    <th>DII NET</th>
                    <th>INST NET</th>
                    <th>FLOW BIAS</th>
                  </tr>
                </thead>
                <tbody>
                  {[1, 10, 20, 60].map((d) => {
                    const key = `d${d}` as "d1" | "d10" | "d20" | "d60";
                    const fw = flowFor(d);
                    const inst = fw && fw.fii != null && fw.dii != null ? fw.fii + fw.dii : null;
                    return (
                      <tr key={d}>
                        <td>{d} DAY</td>
                        <td className={cls(nifty?.changes[key])}>{pct(nifty?.changes[key])}</td>
                        <td className={cls(sensex?.changes[key])}>{pct(sensex?.changes[key])}</td>
                        <td className={cls(fw?.fii)}>{fw?.fii != null ? cr(fw.fii) : <span className="na">—*</span>}</td>
                        <td className={cls(fw?.dii)}>{fw?.dii != null ? cr(fw.dii) : <span className="na">—*</span>}</td>
                        <td className={cls(inst)}>{inst != null ? cr(inst) : <span className="na">—*</span>}</td>
                        <td>
                          {inst == null ? (
                            <span className="chip flat">N/A</span>
                          ) : inst > 0 ? (
                            <span className="chip buy">NET BUYING</span>
                          ) : inst < 0 ? (
                            <span className="chip sell">NET SELLING</span>
                          ) : (
                            <span className="chip flat">FLAT</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              <div className="g-note">
                * Source publishes flow history for the last 30 trading sessions (~6 weeks);
                index moves cover the full 60-session window. Flows are cash-market net,
                ₹ crore, provisional for the latest session.
              </div>
            </div>
          </section>

          {/* ── latest session ── */}
          <section className="panel" id="session">
            <div className="p-head">
              <h2>Latest Session</h2>
              <span className="tag">{lf?.label?.toUpperCase() ?? "—"}</span>
            </div>
            <div className="p-body sess-grid">
              <div className="scard">
                <div className="k">FII Cash Net</div>
                <div className={`v ${cls(lf?.fiiCash)}`}>{cr(lf?.fiiCash)}</div>
                <div className="s">{lf && lf.fiiCash >= 0 ? "net buying" : "net selling"}</div>
              </div>
              <div className="scard">
                <div className="k">DII Cash Net</div>
                <div className={`v ${cls(lf?.diiCash)}`}>{cr(lf?.diiCash)}</div>
                <div className="s">{lf && lf.diiCash >= 0 ? "net buying" : "net selling"}</div>
              </div>
              {lf && (
                <div className="scard wide">
                  <div className="k">Who dominated the session</div>
                  <div className="vsbar">
                    <i className="f" style={{ width: `${(Math.abs(lf.fiiCash) / (Math.abs(lf.fiiCash) + Math.abs(lf.diiCash) || 1)) * 100}%` }} />
                    <i className="d" style={{ width: `${(Math.abs(lf.diiCash) / (Math.abs(lf.fiiCash) + Math.abs(lf.diiCash) || 1)) * 100}%` }} />
                  </div>
                  <div className="vsleg"><span>FII {cr(lf.fiiCash)}</span><span>DII {cr(lf.diiCash)}</span></div>
                </div>
              )}
              <div className="scard">
                <div className="k">FII Index Futures</div>
                <div className={`v ${cls(lf?.fiiIdxFut)}`}>{cr(lf?.fiiIdxFut)}</div>
              </div>
              <div className="scard">
                <div className="k">FII Index Options</div>
                <div className={`v ${cls(lf?.fiiIdxOpt)}`}>{cr(lf?.fiiIdxOpt)}</div>
              </div>
              <div className="scard">
                <div className="k">FII Stock Futures</div>
                <div className={`v ${cls(lf?.fiiStkFut)}`}>{cr(lf?.fiiStkFut)}</div>
              </div>
              <div className="scard">
                <div className="k">FII Stock Options</div>
                <div className={`v ${cls(lf?.fiiStkOpt)}`}>{cr(lf?.fiiStkOpt)}</div>
              </div>
            </div>
          </section>

          {/* ── flows chart ── */}
          <section className="panel" id="flows">
            <div className="p-head">
              <h2>Daily Net Flows · Last {data.flows.length} Sessions</h2>
              <span className="tag">₹ CRORE · CASH MARKET</span>
            </div>
            <div className="p-body">
              <FlowsChart flows={data.flows} />
            </div>
          </section>

          {/* ── daily table ── */}
          <section className="panel" id="ftable">
            <div className="p-head">
              <h2>Session Log</h2>
              <span className="tag">FII / DII NET + F&O POSITIONING</span>
            </div>
            <div className="tbl-wrap">
              <table className="ft">
                <thead>
                  <tr>
                    <th>DATE</th><th>FII CASH</th><th>DII CASH</th><th>IDX FUT</th>
                    <th>IDX OPT</th><th>STK FUT</th><th>STK OPT</th><th>NIFTY</th><th>SENSEX</th>
                  </tr>
                </thead>
                <tbody>
                  {data.flows.map((r) => (
                    <tr key={r.date}>
                      <td>{r.label}</td>
                      <td className={cls(r.fiiCash)}>{cr(r.fiiCash)}</td>
                      <td className={cls(r.diiCash)}>{cr(r.diiCash)}</td>
                      <td className={cls(r.fiiIdxFut)}>{cr(r.fiiIdxFut)}</td>
                      <td className={cls(r.fiiIdxOpt)}>{cr(r.fiiIdxOpt)}</td>
                      <td className={cls(r.fiiStkFut)}>{cr(r.fiiStkFut)}</td>
                      <td className={cls(r.fiiStkOpt)}>{cr(r.fiiStkOpt)}</td>
                      <td>{r.niftyClose != null ? inr(r.niftyClose) : "—"}</td>
                      <td>{r.sensexClose != null ? inr(r.sensexClose) : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </main>
      )}

      <footer>
        {data?.sources.map((s) => (
          <span key={s.name} className={`src ${s.ok ? "" : "bad"}`} title={s.note}>
            <i />{s.name}
          </span>
        ))}
        <span className="disc">
          Snapshot {data ? new Date(data.asOf).toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata" }) : "…"} IST ·
          auto-refresh {POLL_MS / 1000}s · figures ₹ crore, net = buy − sell · educational use, not investment advice.
        </span>
      </footer>
    </>
  );
}
