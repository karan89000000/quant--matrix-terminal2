// Number formatting helpers for the terminal.

export const inr = (n: number | null | undefined, d = 2): string => {
  if (n == null || !Number.isFinite(n)) return "—";
  return n.toLocaleString("en-IN", { minimumFractionDigits: d, maximumFractionDigits: d });
};

/** signed ₹ crore, e.g. "+5,181.62" / "-4,699.14" */
export const cr = (n: number | null | undefined): string => {
  if (n == null || !Number.isFinite(n)) return "—";
  const sign = n > 0 ? "+" : n < 0 ? "-" : "";
  return `${sign}₹${Math.abs(n).toLocaleString("en-IN", { maximumFractionDigits: 0 })} Cr`;
};

/** signed percent, e.g. "+0.67%" */
export const pct = (n: number | null | undefined): string => {
  if (n == null || !Number.isFinite(n)) return "—";
  const sign = n > 0 ? "+" : "";
  return `${sign}${n.toFixed(2)}%`;
};

export const cls = (n: number | null | undefined): string =>
  n == null ? "" : n > 0 ? "up" : n < 0 ? "dn" : "";

export const signCls = cls;
