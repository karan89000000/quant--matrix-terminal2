import { createRouter, publicQuery } from "./middleware";
import type {
  FlowRow,
  IndexSnap,
  MarketSnapshot,
  Sentiment,
  SourceStatus,
} from "@contracts/market";

/* ──────────────────────────────────────────────────────────────────────────
   Live data sources (all fetched server-side to dodge CORS / Akamai):
   1. moneycontrol FII/DII page — embeds ~30 sessions of FII/DII net flows
      (cash market + F&O) plus Nifty/Sensex closes in its __NEXT_DATA__ JSON.
   2. moneycontrol priceapi — daily OHLC history for Nifty 50 (symbol 9) and
      Sensex (symbol 4); the final bar is today's live intraday bar.
   3. tickertape homepage indices — real-time intraday ticks for Nifty 50.
────────────────────────────────────────────────────────────────────────── */

const MC_FIIDII_URL =
  "https://www.moneycontrol.com/stocks/marketstats/fii_dii_activity/index.php";
const MC_HIST_URL = (symbol: number, from: number, to: number) =>
  `https://priceapi.moneycontrol.com/techCharts/techChartController/history?symbol=${symbol}&resolution=1D&from=${from}&to=${to}`;
const TT_INDICES_URL = "https://analyze.api.tickertape.in/homepage/indices";

const SYM_NIFTY = 9;
const SYM_SENSEX = 4;

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

/* ── tiny fetch helper with timeout ─────────────────────────────────────── */
async function getText(url: string, timeoutMs = 12000): Promise<string> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: {
        "User-Agent": UA,
        Accept: "text/html,application/json,*/*",
        "Accept-Language": "en-US,en;q=0.9",
      },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
  } finally {
    clearTimeout(timer);
  }
}

/* ── per-source TTL cache ───────────────────────────────────────────────── */
type CacheEntry = { exp: number; data: unknown };
const cache = new Map<string, CacheEntry>();

async function cached<T>(key: string, ttlMs: number, fn: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && hit.exp > Date.now()) return hit.data as T;
  const data = await fn();
  cache.set(key, { exp: Date.now() + ttlMs, data });
  return data;
}

/* ── number parsing: "-4,699.14" → -4699.14 ─────────────────────────────── */
const num = (v: unknown): number => {
  if (typeof v === "number") return v;
  const n = parseFloat(String(v ?? "").replace(/,/g, ""));
  return Number.isFinite(n) ? n : 0;
};

/* ── source 1: FII/DII flows from moneycontrol __NEXT_DATA__ ────────────── */
async function fetchFlows(): Promise<FlowRow[]> {
  return cached("flows", 10 * 60 * 1000, async () => {
    const html = await getText(MC_FIIDII_URL, 15000);
    const m = html.match(
      /<script id="__NEXT_DATA__" type="application\/json">([\s\S]*?)<\/script>/,
    );
    if (!m) throw new Error("NEXT_DATA not found");
    const parsed = JSON.parse(m[1]);
    const raw =
      parsed?.props?.pageProps?.FiiDiiChartData?.fiiDiiChartData ??
      parsed?.props?.pageProps?.FiiDiiData?.fiiDiiData;
    if (!Array.isArray(raw) || raw.length === 0) throw new Error("no flow rows");
    const rows: FlowRow[] = raw.map((r: Record<string, unknown>) => ({
      date: String(r.date),
      label: String(r.fDate ?? r.date),
      fiiCash: num(r.fiiCM),
      diiCash: num(r.diiCM),
      fiiIdxFut: num(r.fiiIdxFut),
      fiiIdxOpt: num(r.fiiIdxOpt),
      fiiStkFut: num(r.fiiStkFut),
      fiiStkOpt: num(r.fiiStkOpt),
      niftyClose: r.niftyClose != null ? num(r.niftyClose) : null,
      sensexClose: r.sensexClose != null ? num(r.sensexClose) : null,
    }));
    rows.sort((a, b) => (a.date < b.date ? 1 : -1)); // newest first
    return rows;
  });
}

/* ── source 2: daily index history (last bar = live intraday) ───────────── */
type HistBar = { t: number[]; c: number[] };

async function fetchHistory(symbol: number): Promise<HistBar> {
  return cached(`hist:${symbol}`, 45 * 1000, async () => {
    const to = Math.floor(Date.now() / 1000);
    const from = to - 160 * 86400; // ~110 trading sessions
    const text = await getText(MC_HIST_URL(symbol, from, to));
    const d = JSON.parse(text);
    if (d?.s !== "ok" || !Array.isArray(d.t) || !Array.isArray(d.c)) {
      throw new Error(d?.errmsg ?? "bad history payload");
    }
    return { t: d.t as number[], c: d.c as number[] };
  });
}

/* ── source 3: tickertape intraday ticks (Nifty) ────────────────────────── */
type TtNifty = { price: number; points: number[] };

async function fetchTickertape(): Promise<TtNifty> {
  return cached("tt", 20 * 1000, async () => {
    const text = await getText(TT_INDICES_URL, 8000);
    const d = JSON.parse(text);
    const nsei = (d?.data ?? []).find((x: { sid?: string }) => x.sid === ".NSEI");
    if (!nsei) throw new Error("NSEI missing");
    const pts = (nsei.points ?? [])
      .map((p: { price?: number }) => num(p.price))
      .filter((n: number) => n > 0);
    const price = pts.length ? pts[pts.length - 1] : num(nsei.lastClosePrice);
    return { price, points: pts };
  });
}

/* ── IST helpers ────────────────────────────────────────────────────────── */
function istNow(): { ist: string; marketOpen: boolean } {
  const now = new Date();
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    weekday: "short",
    hour12: false,
  }).formatToParts(now);
  const get = (k: string) => parts.find((p) => p.type === k)?.value ?? "";
  const mins = parseInt(get("hour"), 10) * 60 + parseInt(get("minute"), 10);
  const wd = get("weekday");
  const weekday = wd !== "Sat" && wd !== "Sun";
  return {
    ist: `${get("hour")}:${get("minute")}:${get("second")}`,
    marketOpen: weekday && mins >= 9 * 60 + 15 && mins < 15 * 60 + 30,
  };
}

/* ── index snapshot assembly ────────────────────────────────────────────── */
function pctChange(now: number, then: number | undefined): number | null {
  if (then == null || then <= 0) return null;
  return +(((now - then) / then) * 100).toFixed(2);
}

function buildIndex(
  symbol: "NIFTY" | "SENSEX",
  hist: HistBar | null,
  tt: TtNifty | null,
  flowCloses: (number | null)[],
): IndexSnap {
  const closes = hist?.c ?? [];
  // history ends at today's (possibly partial) bar; drop a trailing partial bar
  // only when tickertape gives us a fresher live price for Nifty.
  const lastClose = closes.length ? closes[closes.length - 1] : NaN;
  const prevClose = closes.length > 1 ? closes[closes.length - 2] : NaN;

  const fallbackPrice =
    symbol === "NIFTY" ? flowCloses[0] ?? NaN : flowCloses[0] ?? NaN;
  const price = tt?.price ?? (Number.isFinite(lastClose) ? lastClose : Number(fallbackPrice));
  const live = Boolean(tt) && symbol === "NIFTY";

  const dayChange = +(price - prevClose).toFixed(2);
  const dayChangePct = pctChange(price, prevClose) ?? 0;

  const ago = (n: number) => closes[closes.length - 1 - n] as number | undefined;
  // daily closes, with the freshest tick pinned as the last point
  const base = closes.slice(-40);
  const spark =
    base.length && Number.isFinite(price)
      ? [...base.slice(0, -1), +price.toFixed(2)]
      : base;

  return {
    symbol,
    name: symbol === "NIFTY" ? "NIFTY 50" : "SENSEX",
    price: +price.toFixed(2),
    live,
    prevClose: +prevClose.toFixed(2),
    dayChange,
    dayChangePct,
    changes: {
      d1: pctChange(price, ago(1)),
      d10: pctChange(price, ago(10)),
      d20: pctChange(price, ago(20)),
      d60: pctChange(price, ago(60)),
    },
    spark,
  };
}

/* ── sentiment engine ───────────────────────────────────────────────────── */
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

function sentimentLabel(score: number): Sentiment["label"] {
  if (score >= 20) return "BULLISH";
  if (score <= -20) return "BEARISH";
  return "NEUTRAL";
}

function flowSentiment(rows: FlowRow[], key: "fiiCash" | "diiCash", withFno: boolean): Sentiment {
  if (!rows.length) {
    return { score: 0, label: "NEUTRAL", basis: { d1: null, d10: null, d20: null, fno10: null } };
  }
  const take = (n: number) => rows.slice(0, n);
  const sum = (rs: FlowRow[], k: "fiiCash" | "diiCash") => rs.reduce((a, r) => a + r[k], 0);
  const scale =
    rows.reduce((a, r) => a + Math.abs(r[key]), 0) / rows.length || 1; // mean daily magnitude

  const d1 = sum(take(1), key);
  const d10 = sum(take(10), key);
  const d20 = sum(take(20), key);

  // weighted per-day flow: freshest sessions count most
  const weighted = 0.5 * d1 + 0.3 * (d10 / 10) + 0.2 * (d20 / 20);
  const flowScore = (clamp(weighted / scale, -1.5, 1.5) / 1.5) * 100;

  let score = flowScore;
  let fno10: number | null = null;
  if (withFno) {
    fno10 = take(10).reduce((a, r) => a + r.fiiIdxFut, 0);
    const fnoScore = (clamp(fno10 / (10 * scale), -0.75, 0.75) / 0.75) * 100;
    score = 0.8 * flowScore + 0.2 * fnoScore; // index futures tint the cash signal
  }

  score = +clamp(score, -100, 100).toFixed(1);
  return { score, label: sentimentLabel(score), basis: { d1, d10, d20, fno10 } };
}

/* ── router ─────────────────────────────────────────────────────────────── */
export const marketRouter = createRouter({
  snapshot: publicQuery.query(async (): Promise<MarketSnapshot> => {
    const sources: SourceStatus[] = [];

    let flows: FlowRow[] = [];
    try {
      flows = await fetchFlows();
      sources.push({ name: "moneycontrol fii/dii", ok: true });
    } catch (e) {
      sources.push({ name: "moneycontrol fii/dii", ok: false, note: String(e) });
    }

    let niftyHist: HistBar | null = null;
    try {
      niftyHist = await fetchHistory(SYM_NIFTY);
      sources.push({ name: "priceapi nifty", ok: true });
    } catch (e) {
      sources.push({ name: "priceapi nifty", ok: false, note: String(e) });
    }

    let sensexHist: HistBar | null = null;
    try {
      sensexHist = await fetchHistory(SYM_SENSEX);
      sources.push({ name: "priceapi sensex", ok: true });
    } catch (e) {
      sources.push({ name: "priceapi sensex", ok: false, note: String(e) });
    }

    let tt: TtNifty | null = null;
    try {
      tt = await fetchTickertape();
      sources.push({ name: "tickertape live", ok: true });
    } catch (e) {
      sources.push({ name: "tickertape live", ok: false, note: String(e) });
    }

    const nifty = buildIndex("NIFTY", niftyHist, tt, flows.map((f) => f.niftyClose));
    const sensex = buildIndex("SENSEX", sensexHist, null, flows.map((f) => f.sensexClose));

    const windows = [1, 10, 20, 30].map((days) => {
      if (flows.length < Math.min(days, 1)) return { days, fii: null, dii: null, fno: null };
      const rs = flows.slice(0, days);
      const enough = rs.length >= days;
      return {
        days,
        fii: enough ? +rs.reduce((a, r) => a + r.fiiCash, 0).toFixed(2) : null,
        dii: enough ? +rs.reduce((a, r) => a + r.diiCash, 0).toFixed(2) : null,
        fno: enough ? +rs.reduce((a, r) => a + r.fiiIdxFut, 0).toFixed(2) : null,
      };
    });

    const fii = flowSentiment(flows, "fiiCash", true);
    const dii = flowSentiment(flows, "diiCash", false);

    // index momentum: multi-timeframe Nifty/Sensex drift
    const ch = [nifty.changes, sensex.changes];
    const avg = (k: "d1" | "d10" | "d20" | "d60") => {
      const vs = ch.map((c) => c[k]).filter((v): v is number => v != null);
      return vs.length ? vs.reduce((a, b) => a + b, 0) / vs.length : 0;
    };
    const momRaw = 0.15 * avg("d1") + 0.35 * avg("d10") + 0.3 * avg("d20") + 0.2 * avg("d60");
    const momentumScore = +clamp((momRaw / 6) * 100, -100, 100).toFixed(1); // ±6% drift ≈ full scale
    const overallScore = +clamp(0.45 * fii.score + 0.3 * dii.score + 0.25 * momentumScore, -100, 100).toFixed(1);

    const { ist, marketOpen } = istNow();

    return {
      asOf: new Date().toISOString(),
      ist,
      marketOpen,
      indices: [nifty, sensex],
      latestFlow: flows[0] ?? null,
      flows,
      windows,
      fii,
      dii,
      overall: { score: overallScore, label: sentimentLabel(overallScore), basis: { d1: null, d10: null, d20: null, fno10: null }, momentumScore },
      sources,
    };
  }),
});
