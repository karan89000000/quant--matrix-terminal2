// Shared types for the FII/DII market terminal (frontend + backend).

export type FlowRow = {
  date: string; // ISO yyyy-mm-dd
  label: string; // "Mon 05 Oct, 2026"
  fiiCash: number; // FII net cash-market flow, ₹ crore
  diiCash: number; // DII net cash-market flow, ₹ crore
  fiiIdxFut: number; // FII index futures net, ₹ crore
  fiiIdxOpt: number; // FII index options net, ₹ crore
  fiiStkFut: number; // FII stock futures net, ₹ crore
  fiiStkOpt: number; // FII stock options net, ₹ crore
  niftyClose: number | null;
  sensexClose: number | null;
};

export type IndexChange = { d1: number | null; d10: number | null; d20: number | null; d60: number | null };

export type IndexSnap = {
  symbol: "NIFTY" | "SENSEX";
  name: string;
  price: number; // live (or last close when market is shut)
  live: boolean; // true when price is a real-time intraday tick
  prevClose: number;
  dayChange: number;
  dayChangePct: number;
  changes: IndexChange; // % vs close N trading sessions ago
  spark: number[]; // series for the sparkline (intraday ticks or daily closes)
};

export type FlowWindow = { days: number; fii: number | null; dii: number | null; fno: number | null };

export type SentimentLabel = "BULLISH" | "BEARISH" | "NEUTRAL";

export type Sentiment = {
  score: number; // -100 .. +100
  label: SentimentLabel;
  basis: { d1: number | null; d10: number | null; d20: number | null; fno10: number | null };
};

export type OverallSentiment = Sentiment & { momentumScore: number };

export type SourceStatus = { name: string; ok: boolean; note?: string };

export type MarketSnapshot = {
  asOf: string; // ISO timestamp of this snapshot
  ist: string; // IST wall clock "HH:MM:SS"
  marketOpen: boolean;
  indices: IndexSnap[];
  latestFlow: FlowRow | null;
  flows: FlowRow[]; // newest first, up to ~30 sessions
  windows: FlowWindow[]; // cumulative net flows over 1/10/20/30 sessions
  fii: Sentiment;
  dii: Sentiment;
  overall: OverallSentiment;
  sources: SourceStatus[];
};
